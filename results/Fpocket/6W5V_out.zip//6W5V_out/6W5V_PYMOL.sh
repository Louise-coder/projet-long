#!/bin/bash
pymol 6W5V.pml
