#!/bin/bash
vmd 6W5V_out.pdb -e 6W5V.tcl
